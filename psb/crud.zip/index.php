<?php
require_once "config/main.conf.php";
include $template;