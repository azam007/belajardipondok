<!DOCTYPE html>
<html>
<head>
	<title></title>
<link rel="stylesheet" type="text/css" href="css/radio.css">
</head>
<body>
  <input type="radio" id="radio1" name="radios" value="all" checked>
       <label for="radio1">iPhone</label>
    <input type="radio" id="radio2" name="radios"value="false">
       <label for="radio2">Galaxy S IV</label>
    <input type="radio" id="radio3" name="radios" value="true">
       <label for="radio3">Nexus S</label>

</body>
</html>