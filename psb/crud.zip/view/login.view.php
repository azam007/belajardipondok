<div id="wrapper">
	<div class="login">
		<h1>Login</h1>
		<form method="POST" action="">
			<input type="text" name="username" autocomplete="off">
			<input type="password" name="password" autocomplete="off">
			<input type="submit" name="submit">
		</form>
	</div>
</div>