<div id="wrapper">
	<h1>Selamat Datang dihalaman Admin</h1>
	<h2>Username anda <?=$_SESSION['login']?></h2>
	<a href="?admin=logout">Logout</a>
	Tipe User <?=$typeUser?>
</div>