<div id="wrapper">
	<div class="pemberitahuan">
		<h1>Pendaftaran Online</h1>
		<h2><?=$typeUser?></h2>
		<p>Pondok Programmer merupakan komunitas IT berbasis pondok yang senantiasa berusaha mendidik santrinya untuk berakhlaq mulia, profesional serta bermanfaat untuk ummat.</p>
		<h3>Biaya Gratis 100%</h3>
		<p>Mengapa Gratis? Karena Pondok Programmer memfokuskan kepada anak-anak yang kurang mampu secara ekonomi namun mempunyai minat dan bakat dalam bidang IT khususnya pemrograman.</p>
		<a class='btn-href' href="?p=daftar">Daftar</a> <a class="btn-href" href="?p=login">Login</a><br/><br/>
		<a href="?p=list"><< Lihat Data Calon Santri >></a>
	</div>
</div>